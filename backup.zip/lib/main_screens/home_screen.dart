import 'package:first_app/main_screens/groups_screen.dart';
import 'package:first_app/main_screens/settings_screen.dart';
import 'package:first_app/utilities/assets_manager.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  final PageController _pageController = PageController();

  // List of the main pages
  final List<Widget> _pages = [
    const ChatsPlaceholderScreen(), // Placeholder for your Chats screen
    const GroupsScreen(),
    const PeoplePlaceholderScreen(), // Placeholder for your People screen
  ];

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
      _pageController.jumpToPage(index);
    });
  }

  /// Handles selection from the popup menu
  void _handleMenuSelection(String value) {
    switch (value) {
      case 'settings':
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const SettingsScreen()),
        );
        break;
      case 'profile':
      // TODO: Navigate to user's profile screen
        print('Profile tapped');
        break;
      case 'new_group':
      // TODO: Navigate to a screen for creating a new group
        print('New Group tapped');
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final themeColor = const Color(0xFF2D2F41);
    final accentColor = const Color(0xFF00C853);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 1,
        title: Text(
          'Shonglap',
          style: GoogleFonts.poppins(
            color: themeColor,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              // TODO: Implement search functionality
            },
            icon: Icon(Icons.search, color: themeColor),
          ),
          PopupMenuButton<String>(
            onSelected: _handleMenuSelection,
            icon: Icon(Icons.more_vert, color: themeColor),
            itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
              _buildPopupMenuItem('New Group', Icons.group_add_outlined, 'new_group'),
              _buildPopupMenuItem('My Profile', Icons.person_outline, 'profile'),
              const PopupMenuDivider(),
              _buildPopupMenuItem('Settings', Icons.settings_outlined, 'settings'),
            ],
          ),
        ],
      ),
      body: PageView(
        controller: _pageController,
        onPageChanged: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        children: _pages,
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.chat_bubble_outline),
            activeIcon: Icon(Icons.chat_bubble),
            label: 'Chats',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.people_outline),
            activeIcon: Icon(Icons.people),
            label: 'Groups',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_pin_circle_outlined),
            activeIcon: Icon(Icons.person_pin_circle),
            label: 'People',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: accentColor,
        unselectedItemColor: Colors.grey.shade600,
        onTap: _onItemTapped,
        showUnselectedLabels: true,
        type: BottomNavigationBarType.fixed,
      ),
    );
  }

  /// Helper to build styled popup menu items.
  PopupMenuItem<String> _buildPopupMenuItem(String title, IconData iconData, String value) {
    return PopupMenuItem<String>(
      value: value,
      child: Row(
        children: [
          Icon(iconData, color: Colors.black54),
          const SizedBox(width: 12),
          Text(title),
        ],
      ),
    );
  }
}


// --- Placeholder Widgets for missing screens ---
// You can replace these with your actual screen widgets.

class ChatsPlaceholderScreen extends StatelessWidget {
  const ChatsPlaceholderScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text('Chats Screen', style: TextStyle(fontSize: 24)),
    );
  }
}

class PeoplePlaceholderScreen extends StatelessWidget {
  const PeoplePlaceholderScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text('People Screen', style: TextStyle(fontSize: 24)),
    );
  }
}
