import 'package:first_app/authentication/user_authentication.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:first_app/utilities/assets_manager.dart';

// In your actual app, you would import your existing AssetsManager.
// This is a mock class for demonstration purposes.

class OtpScreen extends StatefulWidget {
  final String phoneNumber;
  const OtpScreen({super.key, required this.phoneNumber});

  @override
  State<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {
  // A list to hold the controllers for each OTP input field.
  final List<TextEditingController> _otpControllers = List.generate(6, (_) => TextEditingController());
  // A list to hold the focus nodes for each OTP input field.
  final List<FocusNode> _focusNodes = List.generate(6, (_) => FocusNode());

  @override
  void initState() {
    super.initState();
    // Add listeners to each controller to automatically move focus to the next field.
    for (int i = 0; i < 6; i++) {
      _otpControllers[i].addListener(() {
        if (_otpControllers[i].text.length == 1 && i < 5) {
          _focusNodes[i + 1].requestFocus();
        }
      });
    }
  }

  @override
  void dispose() {
    // Dispose all controllers and focus nodes to free up resources.
    for (var controller in _otpControllers) {
      controller.dispose();
    }
    for (var focusNode in _focusNodes) {
      focusNode.dispose();
    }
    super.dispose();
  }

  /// Verifies the entered OTP.
  void _verifyOtp() {
    final otp = _otpControllers.map((c) => c.text).join();
    if (otp.length == 6) {
      // TODO: Replace this with your actual OTP verification logic.
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => const UserProfileScreen()),
            (route) => false, // This removes all previous routes from the stack
      );
    } else {
      // Show an error message if the OTP is incomplete.
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please enter the complete 6-digit OTP.', style: GoogleFonts.poppins())),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    final themeColor = const Color(0xFF2D2F41);
    final accentColor = const Color(0xFF00C853);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: themeColor),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24.0),
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    height: 180,
                    width: 230,
                    // Lottie animation for visual appeal.
                    child: Lottie.asset(AssetsManager.otpAnimation, fit: BoxFit.contain),
                  ),
                  const SizedBox(height: 30),
                  Text(
                    'OTP Verification',
                    style: GoogleFonts.poppins(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                      color: themeColor,
                    ),
                  ),
                  const SizedBox(height: 10),
                  // Informational text showing the phone number.
                  Text.rich(
                    TextSpan(
                      text: 'Enter the code sent to ',
                      style: GoogleFonts.openSans(fontSize: 16, color: Colors.black54),
                      children: [
                        TextSpan(
                          text: widget.phoneNumber,
                          style: GoogleFonts.openSans(
                            fontWeight: FontWeight.bold,
                            color: themeColor,
                          ),
                        ),
                      ],
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 40),

                  // The 6 OTP input fields.
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: List.generate(6, (index) {
                      return SizedBox(
                        width: 45,
                        height: 55,
                        child: TextField(
                          controller: _otpControllers[index],
                          focusNode: _focusNodes[index],
                          maxLength: 1,
                          textAlign: TextAlign.center,
                          keyboardType: TextInputType.number,
                          style: GoogleFonts.poppins(fontSize: 22, fontWeight: FontWeight.bold),
                          decoration: InputDecoration(
                            counterText: '',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(color: Colors.grey.shade300),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(color: accentColor, width: 2),
                            ),
                          ),
                          // Handles backspace to move focus to the previous field.
                          onChanged: (value){
                            if(value.isEmpty && index > 0){
                              _focusNodes[index - 1].requestFocus();
                            }
                          },
                        ),
                      );
                    }),
                  ),

                  const SizedBox(height: 30),
                  // Option to resend the OTP.
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Didn't receive the code?",
                        style: GoogleFonts.openSans(color: Colors.black54),
                      ),
                      TextButton(
                        onPressed: () {
                          // TODO: Add your resend OTP logic here.
                          print("Resending OTP to ${widget.phoneNumber}");
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text('OTP resent to ${widget.phoneNumber}', style: GoogleFonts.poppins())),
                          );
                        },
                        child: Text(
                          'Resend',
                          style: GoogleFonts.poppins(
                            fontWeight: FontWeight.bold,
                            color: accentColor,
                          ),
                        ),
                      )
                    ],
                  ),
                  const SizedBox(height: 20),
                  // The main action button to verify the OTP.
                  ElevatedButton(
                    onPressed: _verifyOtp,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: accentColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 14),
                      elevation: 4,
                      minimumSize: const Size(double.infinity, 50),
                    ),
                    child: Text(
                      'Verify & Proceed',
                      style: GoogleFonts.poppins(
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  const SizedBox(height: 30),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
