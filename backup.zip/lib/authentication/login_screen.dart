import 'package:flutter/material.dart';
import 'package:country_picker/country_picker.dart';
import 'package:first_app/utilities/assets_manager.dart'; // Make sure this path is correct
import 'package:first_app/authentication/otp_screen.dart'; // Import the OTP screen file
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  Country selectedCountry = Country(
    phoneCode: '880',
    countryCode: 'BD',
    e164Sc: 0,
    geographic: true,
    level: 1,
    name: 'Bangladesh',
    example: '01812345678',
    displayName: 'Bangladesh (BD) [+880]',
    displayNameNoCountryCode: 'Bangladesh',
    e164Key: '880-BD-0',
  );

  final TextEditingController phoneController = TextEditingController();
  bool hasError = false;

  void _pickCountry() {
    showCountryPicker(
      context: context,
      showPhoneCode: true,
      onSelect: (Country country) {
        setState(() => selectedCountry = country);
      },
    );
  }

  void _validatePhone() {
    setState(() {
      // Basic validation: checks if the length is exactly 11.
      hasError = phoneController.text.length != 10;
    });
  }

  void _clearInput() {
    phoneController.clear();
    setState(() {
      hasError = false; // Reset error state on clear
    });
  }

  /// Navigates to the OTP screen.
  void _goToOtpScreen(String fullNumber) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => OtpScreen(phoneNumber: fullNumber),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final themeColor = const Color(0xFF2D2F41);
    final accentColor = const Color(0xFF00C853);
    final borderColor = hasError
        ? Colors.red
        : FocusScope.of(context).hasFocus
        ? accentColor
        : Colors.transparent;

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24.0),
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center, // Center the content vertically
                children: [
                  const SizedBox(height: 10),
                  SizedBox(
                    height: 180,
                    width: 230,
                    child: Lottie.asset(AssetsManager.loginAnimation, fit: BoxFit.contain),
                  ),
                  const SizedBox(height: 30),
                  Text(
                    'Shonglap',
                    style: GoogleFonts.poppins(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                      color: themeColor,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Add your phone number to verify',
                    style: GoogleFonts.openSans(
                      fontSize: 16,
                      color: Colors.black54,
                    ),
                  ),
                  const SizedBox(height: 30),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(
                        color: borderColor,
                        width: 2,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 15,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        GestureDetector(
                          onTap: _pickCountry,
                          child: Row(
                            children: [
                              Text(selectedCountry.flagEmoji, style: const TextStyle(fontSize: 22)),
                              const SizedBox(width: 6),
                              Text(
                                '+${selectedCountry.phoneCode}',
                                style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w500),
                              ),
                              const Icon(Icons.arrow_drop_down),
                            ],
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: TextField(
                            controller: phoneController,
                            keyboardType: TextInputType.phone,
                            maxLength: 11,
                            decoration: const InputDecoration(
                              hintText: 'Enter your number',
                              counterText: '',
                              border: InputBorder.none,
                            ),
                            // We can validate on change for immediate feedback
                            onChanged: (text) => _validatePhone(),
                          ),
                        ),
                        // Show clear button only when there is text
                        if (phoneController.text.isNotEmpty)
                          IconButton(
                            onPressed: _clearInput,
                            icon: const Icon(Icons.close_rounded),
                            tooltip: 'Clear',
                          ),
                      ],
                    ),
                  ),

                  if (hasError)
                    Padding(
                      padding: const EdgeInsets.only(top: 8.0),
                      child: Text(
                        'Please enter a valid 11-digit phone number',
                        style: GoogleFonts.openSans(color: Colors.red, fontSize: 13),
                      ),
                    ),

                  const SizedBox(height: 30),
                  ElevatedButton(
                    onPressed: () {
                      _validatePhone(); // First, run validation
                      // Then, check if there is NO error and the input is not empty
                      if (!hasError && phoneController.text.isNotEmpty) {
                        final fullNumber = '+${selectedCountry.phoneCode}${phoneController.text}';
                        print('Navigating with number: $fullNumber');
                        _goToOtpScreen(fullNumber); // Navigate to the OTP screen
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: accentColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 14),
                      elevation: 4,
                      minimumSize: const Size(double.infinity, 50), // Make button wider
                    ),
                    child: Text(
                      'Continue',
                      style: GoogleFonts.poppins(
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                        color: Colors.white,
                      ),
                    ),
                  ),

                  const SizedBox(height: 30),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
