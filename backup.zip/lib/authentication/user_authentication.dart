import 'package:first_app/main_screens/home_screen.dart'; // Import the HomeScreen
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:first_app/utilities/assets_manager.dart';

class UserProfileScreen extends StatefulWidget {
  const UserProfileScreen({super.key});

  @override
  State<UserProfileScreen> createState() => _UserProfileScreenState();
}

enum Gender { male, female }

class _UserProfileScreenState extends State<UserProfileScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _dobController = TextEditingController();

  Gender? _selectedGender;
  DateTime? _selectedDate;
  String? _ageErrorText;

  @override
  void dispose() {
    _nameController.dispose();
    _dobController.dispose();
    super.dispose();
  }

  /// Calculates age and checks if the user is at least 12.
  void _validateAge(DateTime pickedDate) {
    final DateTime today = DateTime.now();
    final DateTime twelveYearsAgo = DateTime(today.year - 12, today.month, today.day);

    if (pickedDate.isAfter(twelveYearsAgo)) {
      setState(() {
        _ageErrorText = 'You must be at least 12 years old to register.';
      });
    } else {
      setState(() {
        _ageErrorText = null;
      });
    }
  }

  /// Shows a date picker and updates the state.
  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime(DateTime.now().year - 12, DateTime.now().month, DateTime.now().day),
      firstDate: DateTime(1920, 1),
      lastDate: DateTime.now(),
      helpText: 'Select Your Date of Birth',
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
        _dobController.text = DateFormat('MMMM dd, yyyy').format(picked);
      });
      _validateAge(picked);
    }
  }

  /// Validates user input, saves the profile, and navigates to the HomeScreen.
  void _saveProfileAndNavigate() {
    // --- Input Validation ---
    if (_nameController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter your name.')),
      );
      return;
    }
    if (_selectedDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select your date of birth.')),
      );
      return;
    }
    if (_ageErrorText != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(_ageErrorText!)),
      );
      return;
    }
    if (_selectedGender == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select your gender.')),
      );
      return;
    }

    // --- Data Processing (Placeholder) ---
    // TODO: Add logic to save the user profile data to a database (e.g., Firestore).
    print('Name: ${_nameController.text}');
    print('DOB: ${_dobController.text}');
    print('Gender: ${_selectedGender.toString().split('.').last}');

    // --- Navigation ---
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (context) => const HomeScreen()),
          (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final accentColor = const Color(0xFF00C853);

    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: Text(
          'Setup Profile',
          style: GoogleFonts.poppins(color: Colors.black, fontWeight: FontWeight.w600),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
      ),
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 20.0),
          child: Column(
            children: [
              // --- Profile Picture Avatar ---
              GestureDetector(
                onTap: () {
                  // TODO: Add logic to pick an image from gallery/camera
                  print('Pick profile picture tapped');
                },
                child: CircleAvatar(
                  radius: 50,
                  backgroundColor: Colors.grey.shade200,
                  backgroundImage: AssetImage(AssetsManager.userImage),
                  child: Align(
                    alignment: Alignment.bottomRight,
                    child: Container(
                      height: 30,
                      width: 30,
                      decoration: BoxDecoration(
                          color: accentColor,
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 2)
                      ),
                      child: const Icon(Icons.edit, color: Colors.white, size: 16),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 30),

              // --- Full Name Field ---
              _buildTextField(
                controller: _nameController,
                labelText: 'Full Name',
              ),
              const SizedBox(height: 20),

              // --- Date of Birth Field ---
              _buildTextField(
                  controller: _dobController,
                  labelText: 'Date of Birth',
                  readOnly: true,
                  onTap: () => _selectDate(context),
                  errorText: _ageErrorText
              ),
              const SizedBox(height: 20),

              // --- Gender Selection ---
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Gender',
                    style: GoogleFonts.poppins(
                        color: Colors.grey.shade600,
                        fontSize: 14,
                        fontWeight: FontWeight.w500
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      _buildGenderOption('Male', Gender.male),
                      const SizedBox(width: 16),
                      _buildGenderOption('Female', Gender.female),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 50),

              // --- Save Button ---
              ElevatedButton(
                onPressed: _saveProfileAndNavigate,
                style: ElevatedButton.styleFrom(
                  backgroundColor: accentColor,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  minimumSize: const Size(double.infinity, 50),
                  elevation: 2,
                ),
                child: Text(
                  'Save & Continue',
                  style: GoogleFonts.poppins(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Helper for TextFields
  Widget _buildTextField({
    required TextEditingController controller,
    required String labelText,
    bool readOnly = false,
    VoidCallback? onTap,
    String? errorText,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          labelText,
          style: GoogleFonts.poppins(
              color: Colors.grey.shade600,
              fontSize: 14,
              fontWeight: FontWeight.w500
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: controller,
          readOnly: readOnly,
          onTap: onTap,
          decoration: InputDecoration(
            errorText: errorText,
            contentPadding: const EdgeInsets.symmetric(vertical: 15, horizontal: 16),
            filled: true,
            fillColor: Colors.grey.shade100,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none,
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: const Color(0xFF00C853), width: 1.5),
            ),
          ),
        ),
      ],
    );
  }

  // Helper for Gender selection
  Widget _buildGenderOption(String title, Gender gender) {
    final bool isSelected = _selectedGender == gender;
    return Expanded(
      child: OutlinedButton(
        onPressed: () {
          setState(() {
            _selectedGender = gender;
          });
        },
        style: OutlinedButton.styleFrom(
            backgroundColor: isSelected ? const Color(0xFF00C853).withOpacity(0.1) : Colors.transparent,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            side: BorderSide(
                color: isSelected ? const Color(0xFF00C853) : Colors.grey.shade300,
                width: 1.5
            ),
            padding: const EdgeInsets.symmetric(vertical: 15)
        ),
        child: Text(
          title,
          style: GoogleFonts.poppins(
              color: isSelected ? const Color(0xFF00C853) : Colors.grey.shade700,
              fontWeight: FontWeight.w600
          ),
        ),
      ),
    );
  }
}
